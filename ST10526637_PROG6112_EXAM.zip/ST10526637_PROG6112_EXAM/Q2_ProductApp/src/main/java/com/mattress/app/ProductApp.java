package com.mattress.app;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Question 2: GUI application for capturing and processing a mattress sale.
 */
public final class ProductApp extends JFrame {

    private static final long serialVersionUID = 1L;

    private static final String FILE_NAME = "data.txt";
    private static final String[] PRODUCTS = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
    private static final String DIVIDER = "*".repeat(28);

    // Form controls (Q.2.2)
    private final JTextField txtCustomerName = new JTextField(20);
    private final JComboBox<String> cmbProduct = new JComboBox<>(PRODUCTS);
    private final JTextField txtPrice = new JTextField(20);
    private final JButton btnProcess = new JButton("PROCESS");

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setJMenuBar(createMenuBar());
        add(createFormPanel(), BorderLayout.CENTER);

        btnProcess.addActionListener(e -> processSale());

        pack();
        setLocationRelativeTo(null); // centre on screen
    }

    /** Builds the File and Tools menus (Q.2.4). */
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale()); // same logic as the button
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    /** Lays out the labels, inputs and Process button. */
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addRow(panel, gbc, 0, "Customer Name:", txtCustomerName);
        addRow(panel, gbc, 1, "Select Product:", cmbProduct);
        addRow(panel, gbc, 2, "Enter Price:", txtPrice);

        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(btnProcess, gbc);
        return panel;
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label,
                        java.awt.Component field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    /**
     * Q.2.3: validates input, calculates VAT, commission and total,
     * shows the result in a message box and saves it to data.txt.
     */
    private void processSale() {
        String customerName = txtCustomerName.getText().trim();
        String productName = (String) cmbProduct.getSelectedItem();

        if (customerName.isEmpty()) {
            showError("Please enter the customer's name.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
            if (price < 0) {
                showError("Price cannot be negative.");
                return;
            }
        } catch (NumberFormatException ex) {
            showError("Please enter a valid numeric price.");
            return;
        }

        IProductCalculations calc = new ProductCalculations(price);

        // One method builds the details so the message box and file stay identical
        String details = buildDetails(customerName, productName, calc);

        JOptionPane.showMessageDialog(this, details, "Message", JOptionPane.INFORMATION_MESSAGE);
        saveToFile(details);
    }

    private String buildDetails(String customerName, String productName, IProductCalculations calc) {
        return "Customer Name: " + customerName + "\n"
                + "Product: " + productName + "\n"
                + "VAT: R " + calc.GetVat() + "\n"
                + "COMMISSION: R " + calc.GetCommission() + "\n"
                + "TOTAL: R " + calc.GetTotal();
    }

    /** Writes the data log to data.txt (overwrites the previous log). */
    private void saveToFile(String details) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            writer.println("DATA LOG");
            writer.println(DIVIDER);
            writer.println(details);
            writer.println(DIVIDER);
        } catch (IOException ex) {
            showError("Could not save to " + FILE_NAME + ": " + ex.getMessage());
        }
    }

    /** Clears the text boxes and resets the combo box to the first item. */
    private void clearForm() {
        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProduct.setSelectedIndex(0);
        txtCustomerName.requestFocus();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        // Swing components must be created on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
