package com.mattress.report;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Product class (Q.1.4).
 * Uses the same figures as the sample screenshot in the question paper.
 */
public class ProductTest {

    private Product product;

    @BeforeEach
    public void setUp() {
        String[] names = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = {
            {25, 18, 20},
            {15, 10, 12},
            {18, 15, 20}
        };
        product = new Product(names, sales);
    }

    /** Unit Test 1: GetTotalProductsSold returns the total products sold. */
    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        int expected = 153;
        int actual = product.GetTotalProductsSold();
        assertEquals(expected, actual);
    }

    /** Unit Test 2: GetAverageProductSold returns the average number of products sold. */
    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        double expected = 17.0; // 153 / 9
        double actual = product.GetAverageProductSold();
        assertEquals(expected, actual, 0.001);
    }

    /** Extra test: the product with the highest total sales is returned. */
    @Test
    public void GetMostPopularProduct_WithValidData_ReturnsCorrectValue() {
        assertEquals("Cozy Nights Monarch", product.GetMostPopularProduct());
    }
}
