package com.mattress.report;

/**
 * Holds the sales data for the top-performing products and performs
 * the report calculations.
 *
 * Data layout:
 *   productNames[p]   -> single-dimensional array of product names
 *   sales[p][m]       -> two-dimensional array, row = product, column = month
 */
public class Product implements IProduct {

    private final String[] productNames;
    private final int[][] sales;

    /**
     * @param productNames one name per product (rows of the sales array)
     * @param sales        sales figures, one row per product, one column per month
     */
    public Product(String[] productNames, int[][] sales) {
        if (productNames == null || sales == null || productNames.length != sales.length) {
            throw new IllegalArgumentException("Each product must have exactly one row of sales data.");
        }
        this.productNames = productNames;
        this.sales = sales;
    }

    /** Adds up every sale across all products and all months. */
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] productSales : sales) {
            for (int monthSales : productSales) {
                total += monthSales;
            }
        }
        return total;
    }

    /**
     * Average sales per product per month
     * (total sales divided by the number of sales entries, e.g. 153 / 9 = 17).
     */
    @Override
    public double GetAverageProductSold() {
        int entries = 0;
        for (int[] productSales : sales) {
            entries += productSales.length;
        }
        // Guard against division by zero when there is no data
        return entries == 0 ? 0 : (double) GetTotalProductsSold() / entries;
    }

    /** Returns the name of the product with the highest total sales. */
    @Override
    public String GetMostPopularProduct() {
        return productNames[getMostPopularIndex()];
    }

    /** Total sales for one product (one row of the 2D array). */
    public int getProductTotal(int productIndex) {
        int total = 0;
        for (int monthSales : sales[productIndex]) {
            total += monthSales;
        }
        return total;
    }

    /** Highest single-month sale for one product. */
    public int getHighestMonthlySale(int productIndex) {
        int highest = 0;
        for (int monthSales : sales[productIndex]) {
            if (monthSales > highest) {
                highest = monthSales;
            }
        }
        return highest;
    }

    /** Index of the product whose total sales are the highest. */
    public int getMostPopularIndex() {
        int bestIndex = 0;
        for (int p = 1; p < productNames.length; p++) {
            if (getProductTotal(p) > getProductTotal(bestIndex)) {
                bestIndex = p;
            }
        }
        return bestIndex;
    }
}
