package com.mattress.app;

/**
 * Calculates VAT, commission and the total sale amount for one product price.
 *   VAT        = 15% of price
 *   Commission = 5% of price
 *   Total      = price + VAT + commission
 */
public class ProductCalculations implements IProductCalculations {

    private static final double VAT_RATE = 0.15;
    private static final double COMMISSION_RATE = 0.05;

    private final double price;

    public ProductCalculations(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative.");
        }
        this.price = price;
    }

    @Override
    public double GetVat() {
        return roundToCents(price * VAT_RATE);
    }

    @Override
    public double GetCommission() {
        return roundToCents(price * COMMISSION_RATE);
    }

    @Override
    public double GetTotal() {
        return roundToCents(price + GetVat() + GetCommission());
    }

    /** Rounds to 2 decimal places so floating-point noise never shows in output. */
    private static double roundToCents(double amount) {
        return Math.round(amount * 100.0) / 100.0;
    }
}
