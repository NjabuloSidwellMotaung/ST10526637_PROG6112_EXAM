package com.mattress.app;

/**
 * Contract for the sale calculations (Q.2.5).
 * Method names are kept exactly as given in the question paper.
 */
public interface IProductCalculations {

    double GetVat();

    double GetCommission();

    double GetTotal();
}
